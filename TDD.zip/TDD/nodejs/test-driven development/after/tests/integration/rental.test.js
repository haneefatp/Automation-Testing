const moment = require('moment');
const request = require('supertest');
const {Rental} = require('../../models/rental');
const {Customer} = require('../../models/customer');
const {Movie} = require('../../models/movie');
const {User} = require('../../models/user');
const mongoose = require('mongoose');

describe('/api/rental', () => {
  let server; 
  let customerId; 
  let movieId;
  let rental;
  let token;
  let movie;
  let customer;

  const exec = () => {
    return request(server)
      .post('/api/rental')
      .set('x-auth-token', token)
      .send({ customerId, movieId });
  };

  beforeEach(async () => { 
    server = require('../../index'); 

    customerId = mongoose.Types.ObjectId();
    movieId = mongoose.Types.ObjectId();
    token = new User().generateAuthToken();

    rental = new Rental({
      customer: {
        _id: customerId,
        name: '12345',
        phone: '12345'
      },
      movie: {
        _id: movieId,
        title: '12345',
        dailyRentalRate: 2
      }
    });
    await rental.save();

    movie = new Movie({
      _id: movieId,
      title: 'disko dancer',
      genre: {
        name: 'action'
      },
      numberInStock: 0,
      dailyRentalRate: 10
    });

    await movie.save();  
    
    customer = new Customer({
      name: 'Haneefa',
      phone: '123456'
    });
    await customer.save();
  });  

  afterEach(async () => { 
    await server.close(); 
    await Rental.remove({});
    await Movie.remove({});
    await Customer.remove({});
  });  

  it('should works', () => {
    const result = Rental.findById(rental._id);
    expect(result).not.toBeNull();
  });

  it('return 401 if the user is not logged in', async () => {
    token = '';
    const response = await exec();
    expect(response.status).toBe(401);
  });

  it('return 400 if there is no valid customeId provided', async () => {
    customerId = 'mutta';
    const response = await exec();
    expect(response.status).toBe(400);
  });

  it('return 400 if there is no valid movieId provided', async () => {
    movieId = '';
    const response = await exec();
    expect(response.status).toBe(400);
  });

  it('return 400 if there is no valid movieId provided', async () => {
    movieId = '';
    const response = await exec();
    expect(response.status).toBe(400);
  });

  it('return 404 if the movie is out of stock', async () => {
    let result = await Movie.collection.findOne({_id: movie._id});
    expect(result.numberInStock).toBe(0);

    // const response = await exec();
    // expect(response.status).toBe(404);
  });

  it('return 400 if there is a valid rental exist for the customer/movie', async () => {
    await exec();
    const response = await exec();
    expect(response.status).toBe(400);
  });

  it('return 200 when a valid rental saved', async () => {
    const response = await exec();
    expect(response.status).toBe(200);
  });
});