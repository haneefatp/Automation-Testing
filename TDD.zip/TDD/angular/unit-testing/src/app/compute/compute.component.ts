import { Component } from '@angular/core';

@Component({
  selector: 'app-compute',
  templateUrl: './compute.component.html',
  styleUrls: ['./compute.component.css']
})
export class ComputeComponent{

  constructor() { }

  calculate(number) {
    if(number < 0) {
      return 0
    }

    return number + 1;
  }

}
