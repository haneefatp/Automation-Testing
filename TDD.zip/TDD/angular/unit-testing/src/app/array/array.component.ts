import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-array',
  templateUrl: './array.component.html',
  styleUrls: ['./array.component.css']
})
export class ArrayComponent{
  currencies = ['INR', 'USD', 'AUD']

  constructor() { }

  getCurrencies() {
    return this.currencies;
  }

}
