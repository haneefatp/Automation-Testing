import { async, TestBed, ComponentFixture } from '@angular/core/testing';

import { FormComponent } from './form.component';
import { FormBuilder } from '@angular/forms';

describe('FormComponent', () => {
  let component: FormComponent;
  let fixture: ComponentFixture<FormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.ngOnInit();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should contain form with two controls', () => {    
    expect(component.contactForm.contains('name')).toBeTruthy();
    expect(component.contactForm.contains('email')).toBeTruthy();
  });

  it('should make name control required', () => {
    let control = component.contactForm.get('name');
    control.setValue('Haneefa');    
    expect(control.valid).toBeTruthy();
    component.onSubmit();
  });
});
